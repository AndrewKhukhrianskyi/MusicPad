from kivy.app import App
from kivy.clock import Clock
from kivy.uix.button import Button
from kivy.uix.widget import Widget
from kivy.uix.gridlayout import GridLayout
from kivy.uix.slider import Slider
from kivy.config import Config
from kivy.core.window import Window
from kivy.core.audio import SoundLoader
from kivy.core.audio import Sound
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.label import Label
from kivy.properties import *


Config.set('graphics','resizable','0');
Config.set('graphics','height', '500');
Config.set('graphics','width','400');


class Pad(Button):
    def __init__(self, musicfile, bind, **kwargs):
        super(Pad, self).__init__(**kwargs)
        self.sound = SoundLoader.load(musicfile)
        self.keybind = bind
    
    def on_press(self):
        self.sound.play()
        self.sound.seek(0)
        super(Pad, self).on_press()
                 
        
class MusicPad(GridLayout):
    def __init__(self, **kwargs):
        super(MusicPad,self).__init__(rows=4, spacing=2, **kwargs)
        self._keyboard = Window.request_keyboard(self._keyboard_closed,self)
        self._keyboard.bind(on_key_down = self._on_keyboard_down)

        self.pads = {
            'lead1.mp3': {'key': 'numpad7', 'color': (.8,.0,.0,1)}, 
            'lead2.mp3': {'key': 'numpad8', 'color': (.8,.0,.0,1)},
            'lead3.mp3': {'key': 'numpad9', 'color': (.8,.0,.0,1)},
            'lead4.mp3': {'key': 'numpad4', 'color': (.8,.0,.0,1)},
            'lead5.mp3': {'key': 'numpad5', 'color': (.8,.0,.0,1)},
            'lead6.mp3': {'key': 'numpad6', 'color': (.8,.0,.0,1)},
            'bass1.mp3': {'key': 'numpad1', 'color': (.7,.6,.0,1)},
            'bass2.mp3': {'key': 'numpad2', 'color': (.7,.6,.0,1)},
            'bass3.mp3': {'key': 'numpad3', 'color': (.7,.6,.0,1)},
            'kick.mp3':  {'key': 'numpad0', 'color': (.0,.0,.8,1)},
            'hat.mp3':   {'key': 'numpaddecimal', 'color': (.0,.0,.8,1)},
            'snare.mp3': {'key': 'numpadenter', 'color': (.0,.0,.8,1)},
        }
        
        for filename, config in self.pads.items():
            self.add_widget(Pad(filename, config['key'], background_color=config['color'], 
                                                    background_normal='', size_hint=(.5,.5)))
        self.set_volume(None, 0)
        
                        
    def _keyboard_closed(self):
        self._keyboard.unbind(on_key_down = self._on_keyboard_down)
        self._keyboard = None
        
    def _on_keyboard_down(self, keyboard, keycode, text=None ,modifiers=[]):
        if len(keycode) == 2:
            for button in tuple(filter(lambda x: keycode[1]==x.keybind, self.children)):
                button.on_press()
                button._do_press()
                button._clockev = Clock.schedule_once(button._do_release, .15)

    def set_volume(self, slider, value):
        for child in self.children:
            child.sound.volume = value

class MainClass(BoxLayout):
    def __init__(self,**kwargs):
        super(MainClass,self).__init__(orientation = 'vertical', padding=25,**kwargs)
        self.music_pad = MusicPad()
        
        self.slide = Slider(min=0, max=1, step=0.1)
        self.slide.bind(value = self.music_pad.set_volume)
        
        self.add_widget(self.slide)
        self.add_widget(self.music_pad)
            

class MusicApp(App):            
    def build(self):
        return MainClass()
    

if __name__ == '__main__':
    MusicApp().run()
